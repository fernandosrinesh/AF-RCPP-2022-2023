#ifndef RUNMONTECARLO_H
#define RUNMONTECARLO_H

// prototype of the function
double runMonteCarlo(double x, int NumberofSamples);

#endif