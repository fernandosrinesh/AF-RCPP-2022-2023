#include <Rcpp.h>
#include "runMonteCarlo.h"
#include <bits/stdc++.h>
#include <random>
#include <math>
using namespace Rcpp;
using namespace std;

// [[Rcpp::export]]
double getTheoreticalPrice(
    double Expiry = 0.5,
    double Strike = 100,
    double Spot   = 120,
    double Vol    = 0.2,
    double r      = 0.06,
    unsigned long NumberOfPaths = 10000){
      double d1 = (log(Spot/Strike) + (r + Vol * Vol / 2) * Expiry) / (Vol * sqrt(Expiry));
      double d2 = d1 - Vol * sqrt(Expiry);

  double result1 = Spot * runMonteCarlo(d1, NumberOfPaths);
  double result2 = Strike * exp(-r * Expiry) * runMonteCarlo(d2, NumberOfPaths);
  double result = result1 + result2;

	return result;
}


