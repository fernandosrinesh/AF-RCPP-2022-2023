#include "getPDFofGaussian.h"
#include <cstdlib>
#include <bits/stdc++.h>
#include <math>
double getPDFofGaussian(double x){
	double result;


	double c = 1/sqrt(2 * M_PI);
	

	result = c * exp(-(x * x)/2);

	return result;

}
