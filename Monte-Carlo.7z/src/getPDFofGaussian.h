#ifndef GETPDFOFGAUSSIAN_H
#define GETPDFOFGAUSSIAN_H

double getPDFofGaussian(double x);
       
#endif

